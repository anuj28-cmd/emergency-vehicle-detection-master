# Indian_Balanced_Dataset 2 > 2024-08-15 3:45am
https://universe.roboflow.com/hf-riaag/indian_balanced_dataset-2

Provided by a Roboflow user
License: CC BY 4.0

